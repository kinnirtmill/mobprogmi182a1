package com.example.milestokilometer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonmilestokilometer = (Button) findViewById(R.id.milestokilometer);
        buttonmilestokilometer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText textBoxMiles = (EditText) findViewById(R.id.editTextmiles);
                EditText textBoxkm = (EditText) findViewById(R.id.editTextkm);
                double vMiles = Double.valueOf(textBoxMiles.getText().toString());
                double vKilometer = vMiles / 0.62137;
                DecimalFormat formatVal = new DecimalFormat("##.##");
                textBoxkm.setText(formatVal.format(vKilometer));

            }
        });
        Button buttonkilometertomiles = (Button) findViewById(R.id.kilometertomiles);
        buttonkilometertomiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText textBoxMiles = (EditText) findViewById(R.id.editTextmiles);
                EditText textBoxKm = (EditText) findViewById(R.id.editTextkm);
                double vKm = Double.valueOf(textBoxKm.getText().toString());
                double vMiles = vKm * 0.62137;
                DecimalFormat formatVal = new DecimalFormat("##.##");
                textBoxMiles.setText(formatVal.format(vMiles));
            }
        });
    }
}